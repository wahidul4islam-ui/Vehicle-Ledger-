Vehicle Ledger v7 (original logo)
1) Copy assets/public/* into your project's assets/public (index.html + icon PNGs), rebuild APK.
2) Phone launcher icon: copy android-icons/mipmap-*/ to res/ (replace ic_launcher.png and ic_launcher_round.png), or use Android Studio > Image Asset with icon-512.png.
3) index.html also opens directly in a browser.
4) App name: also set app_name = "Vehicle Ledger" in res/values/strings.xml (and appName in capacitor.config if you use Capacitor).
